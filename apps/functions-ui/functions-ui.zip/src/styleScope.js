// used both at runtime and build time
module.exports = {
  styleScope: 'functions-ui-style-scope',
};

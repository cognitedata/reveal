export const environment = {
  production: true,
  APP_ENV: 'mock',
};

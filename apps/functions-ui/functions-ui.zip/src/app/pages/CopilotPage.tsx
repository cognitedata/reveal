import { Col, Row, Title } from '@cognite/cogs.js';

export const CopilotPage = () => {
  return (
    <div>
      <Row>
        <Col>
          <br />
          <br />
          <Title>hello</Title>
        </Col>
      </Row>
    </div>
  );
};

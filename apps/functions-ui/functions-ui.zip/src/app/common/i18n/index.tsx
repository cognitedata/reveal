import * as en from './en/copilot.json';

/**
 * copilot app translations
 */
export const translations = {
  en: { copilot: en },
};
